/*
DO NOT EDIT.
This file was automatically created by the Matlab function 'create_sfun_decode' on 06-Sep-2024 10:29:01
as part of Simulink MAVLink library.
*/

#include "C:\Users\csin097\OneDrive - The University of Auckland\Chantelle - RA\Mug Drone Demo  - AUG 2024\include\sfun_mavlink_msg_attitude.h"
#include "C:\Users\csin097\OneDrive - The University of Auckland\Chantelle - RA\Mug Drone Demo  - AUG 2024\include\sfun_mavlink_msg_battery_status.h"

#define NFIELDS_OUTPUT_BUS (NFIELDS_BUS_ATTITUDE + NFIELDS_BUS_BATTERY_STATUS)

#define OFFSET_ATTITUDE 0
#define OFFSET_BATTERY_STATUS 2*(NFIELDS_BUS_ATTITUDE)

/*
Decode the incoming MAVLink message
*/
static inline void decode_mavlink_msg (SimStruct *S, const mavlink_message_t *msg)
{
	int_T *busInfo = (int_T *) ssGetUserData(S);

	char* yvec0 = (char *) ssGetOutputPortRealSignal(S, 0);
	char* yvec1 = (char *) ssGetOutputPortRealSignal(S, 1);
	switch (msg->msgid) {

		case MAVLINK_MSG_ID_ATTITUDE:
			decode_msg_attitude(msg, busInfo, yvec0, OFFSET_ATTITUDE);
			break;

		case MAVLINK_MSG_ID_BATTERY_STATUS:
			decode_msg_battery_status(msg, busInfo, yvec1, OFFSET_BATTERY_STATUS);
			break;
	}
}
